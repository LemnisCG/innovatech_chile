(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_04cnvxr._.js","static/chunks/0z3k_next_dist_compiled_next-devtools_index_0xkte8i.js","static/chunks/0z3k_next_dist_compiled_react-dom_0jt1g-9._.js","static/chunks/0z3k_next_dist_compiled_react-server-dom-turbopack_0_40f42._.js","static/chunks/0z3k_next_dist_compiled_0gwbq.k._.js","static/chunks/0z3k_next_dist_client_0d8~-ww._.js","static/chunks/0z3k_next_dist_12621z2._.js","static/chunks/0i4a_@swc_helpers_cjs_0hvz.20._.js"],
    source: "entry"
});
