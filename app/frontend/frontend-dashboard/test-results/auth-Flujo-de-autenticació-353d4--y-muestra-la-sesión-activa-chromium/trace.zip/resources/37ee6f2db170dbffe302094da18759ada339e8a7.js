(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__02nfq85._.css","static/chunks/0z3k_next_dist_0qliqep._.js"],
    source: "dynamic"
});
